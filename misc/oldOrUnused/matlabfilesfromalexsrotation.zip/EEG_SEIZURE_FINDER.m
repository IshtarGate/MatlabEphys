%% import file to be analyzed - must be exported from LabChart in .mat format
%% be careful of file size.  Too big seems to yield error and prevent importing
[filename,pathname]=uigetfile('*.mat','Pick a MATLAB code file');
cd(pathname);
filepath=[pathname filename];
data=importdata(filepath);
filename
%%
tic  % start timing
%% create scaled axes
x=data.data_block1*3.125e-4;
time=linspace(1,size(x,2),size(x,2)); % create variable for time of same matrix size as data
time=time/60000; %translate time units from ms to seconds
%% not using this plot right now - included in subplotted figure (upper image)
% plot(time,x)
% title('EEG seizure waveform')
% xlabel('time (min)')
% ylabel('voltage (V)')
%% define bins
binnum = time(1,1:(size(time,2)-100));
binscore = zeros(1,size(time,2)-100);
binsize = 100;
%%
counter=1; % start counter at 1
for i = 1:size(binnum,2) % for each bin i (1000 data points each, 1=start, (# data points minus 1000)=end)
    voltsum = 0; % start voltsum at zero; will be incremented from here
    for j = i:(i+(binsize-1)) % for each data point j in a given bin
        k = abs(x(1,i)); % k = the absolute value of data point j
        voltsum = voltsum+k; % voltsum incrementally increased by k for each point j within bin
    end % end loop within each bin
    binscore(1,i)=voltsum; % binscore at row i is set equal to voltsum for bin i
    i = (i+1); %increment counter by 1
end % end bin-by-bin loop
%% not using this figure right now - included in sub-plotted figure (lower image)
% figure % create a new figure
% plot(binnum,smooth(binscore,10000)) % chart of average magnitude over 10-second bins
% title('EEG waveform magnitude 1-sec moving average')
% xlabel('time(min)')
% ylabel('10-sec moving average (mV)')
%%
figure % create new figure
subplot(2,1,1) % create a two-tiered plot to compare raw and bin-averaged EEG readouts - top chart
plot(time,x) % plot raw EEG
xlabel('time(min)')
ylabel('Voltage (V)')
subplot(2,1,2) % bottom chart
plot(binnum,smooth(binscore,10000)) % average magnitude over 10-second bins
ylabel('Avg voltage (mV)')
set(gca,'XTickLabel',{})
%% identify seizure timepoints
smoothscore = smooth(binscore,10000);
smoothaverage = mean(smoothscore(:,1));
findpeaks(smoothscore(:,1),'MinPeakProminence',(2*smoothaverage));
ylabel('Avg voltage (mV)')
set(gca,'XTickLabel',{})
[peaks, peaklocs]=findpeaks(smoothscore(:,1),'MinPeakProminence',(2*smoothaverage),'annotate','extents');
[smoothaverage, peaks, peaklocs];
peakdata = [peaklocs,peaks];  % need to export peakdata to excel sheet; 
% peakdata column 1 is the peaks' locations while column 2 is their extents
%%
toc % stop timing
