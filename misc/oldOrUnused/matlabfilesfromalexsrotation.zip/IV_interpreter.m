[filename,pathname]=uigetfile('*.abf','Pick a MATLAB code file');  % pick a file
cd(pathname); % change location to new folder
filepath=[pathname filename]; % create variable for whole file path
[data,si,header]=abfload(filepath); % load .abf file data2 and sample interval
%% User input to define the type of protocol that created the data file being analyzed
data2 = zeros(size(data,1),size(data,2),size(data,3));
prompt = 'Input sweep subtraction. 0 = no subtraction(IV); 1 = subtract first sweep (rec); 2 = subtract last sweep (hinf): ';
result = input(prompt);
%% Subtract first or last sweep to correct for hinfinity or recovery protocols (or not, for IV protocol)
if result==0 % for IV protocol
    data2=data;
elseif result==1 % for recovery protocol
    for n = 1:size(data,3) % for each sweep
        data2(:,1,n) = (data(:,1,n))-(data(:,1,1)); % data2 is variable defined as sweep# minus first sweep
    end
elseif result==2 % for h-infinity protocol
    for n = 1:size(data,3) % for each sweep
        data2(:,1,n) = (data(:,1,n))-(data(:,1,size(data,3))); % data2 is variable defined as sweep# minus final sweep
    end
else prompt = 'Incorrect entry. Input sweep subtraction. 0 = no subtraction(IV); 1 = subtract first sweep (rec); 2 = subtract last sweep (hinf): '; %if response is outside these options, re-prompt with same question.
    result = input(prompt); % if first try yields incorrect entry, repeat process again
    if result==0 % for IV protocol
    data2=data;
    elseif result==1 % for recovery protocol
        for n = 1:size(data,3) % for each sweep
        data2 = (data(:,1,n))-(data(:,1,1)); % data2 is variable defined as sweep# minus first sweep
        end
    elseif result==2 % for h-infinity protocol
        for n = 1:size(data,3) % for each sweep
        data2 = (data(:,1,n))-(data(:,1,size(data,3))); % data2 is variable defined as sweep# minus final sweep
        end
    else data2 = data;
        prompt = 'Incorrect entry. Analysis will continue without subtracting a sweep or otherwise modifying data.';
    end
end
%%
figure
if result==1 % for rec protocol
    plot(data2(:,1,25)) % make plot without time on x axis to define sampling range within which to seek peaks
    xlabel('Time (ms)')
    ylabel('Current (pA)')
    [x,~]=ginput(2); % prompts user to select time range with crosshairs
    x=round(x); % rounds exact locations selected to the nearest integer
elseif result==2 % for hinf protocol
    plot(data2(:,1,3)) % make plot without time on x axis to define sampling range within which to seek peaks
    xlabel('Time (ms)')
    ylabel('Current (pA)')
    [x,~]=ginput(2); % prompts user to select time range with crosshairs
    x=round(x); % rounds exact locations selected to the nearest integer
else % specifically, for result==0, IV protocol.  Previous section requires input to be 0, 1, or 2.
    plot(data2(:,1,15)) % make plot without time on x axis to define sampling range within which to seek peaks
    xlabel('Time (ms)')
    ylabel('Current (pA)')
    [x,~]=ginput(2); % prompts user to select time range with crosshairs
    x=round(x); % rounds exact locations selected to the nearest integer
end
%% Plot the trace (corrected trace, if hinf or recovery)
time = linspace(0,(5160*30/1000),5160); % define time variable - 30ms per data2 point across 5160 data2 points
plot(time(x(1):x(2)),data2(x(1):x(2),1,5),time(x(1):x(2)),data2(x(1):x(2),1,6),time(x(1):x(2)),data2(x(1):x(2),1,7),time(x(1):x(2)),data2(x(1):x(2),1,8),time(x(1):x(2)),data2(x(1):x(2),1,9),time(x(1):x(2)),data2(x(1):x(2),1,10),time(x(1):x(2)),data2(x(1):x(2),1,11),time(x(1):x(2)),data2(x(1):x(2),1,12),time(x(1):x(2)),data2(x(1):x(2),1,13),time(x(1):x(2)),data2(x(1):x(2),1,14),time(x(1):x(2)),data2(x(1):x(2),1,15),time(x(1):x(2)),data2(x(1):x(2),1,16),time(x(1):x(2)),data2(x(1):x(2),1,17),time(x(1):x(2)),data2(x(1):x(2),1,18),time(x(1):x(2)),data2(x(1):x(2),1,19),time(x(1):x(2)),data2(x(1):x(2),1,20));
% 27 sweeps in Alex's files.  But # of sweeps shouldn't matter - use size(data2,3) to adapt to file
xlabel('Time(ms)')
ylabel('Current (pA)')
%% create a matrix to gather the peak of each sweep into a list
table = zeros(size(data2,3),3);
for n = 1:size(data2,3) % for the number of sweeps in the data2 file
    pk = min(data2(x(1):x(2),1,n)); % find the negative peak (aka min) of sweep n
    table(n,1) = n; % save sweep number n into column 1, row n of 'table' matrix
    table(n,2) = pk; % save the magnitude of sweep n's minimum value into column 2, row n of 'table' matrix
    if result==0
        table(n,3) = ((-80)+((n-1)*5));
    else table(n,3) = 0;
    end
end
%%
figure
if result==0
    plot(table(:,3),table(:,2)) % plot peaks(3) x-axis vs peaks(2) y-axis to compare max currents for sweeps at each voltage
    title('Maximum Current Density')
    xlabel('Voltage (mV)')
    ylabel('Current (pA)')
else plot(table(:,1),table(:,2))
    title('Maximum Current Density')
    xlabel('Sweep Number')
    ylabel('Current (pA)')
end
%% tau: find the time from peak to when trace returns 67% of the way to baseline (0)
%tvals = zeros(size(data2,1),1,size(data2,3));
%tmax = zeros(1,size(data2,3));
%data21 = (-1)*data2;
%pklocs = zeros(1,size(data2,3));
%decaytime = zeros(1,size(data2,3));
%for n = 1:size(data2,3) % for the number of sweeps in the data2 file
%    pk = min(data2(:,1,n)); % find the negative peak (aka min) of sweep n (this repeats peak section and can be cut if necc to save time)
%    t = find(data2(:,1,n)<(pk*(.33))); % find data2 = 0.33*peak
%    tvals(1:size(t),1,n) = t; % save all times with (magnitude > 0.33*peak for sweep) to matrix tvals
%    tmax(1,n) = max(t); % save latest (timepoint > 0.33*peak for sweep) for each sweep into matrix tmax
%    [pks,pktimes] = findpeaks(data21(:,1,n),'SortStr','descend');
%    pklocs(1,n) = pktimes(1,1);
%    decaytime(1,n) = (tmax(1,n))-(pklocs(1,n)); % is this necessary?
%end
%(then still need to calculate tau using decay function(?) over the period)
%(covered by 'decaytime' - from pklocs to tmax for each sweep)
%%
disp('copy output to excel');
openvar('table');